package com.safeway.osdc;
import lombok.SneakyThrows;
import org.testng.asserts.SoftAssert;

import java.io.*;
import java.io.PrintWriter;

import org.testng.asserts.IAssert;

public class SimpleLoggingAssert extends SoftAssert {

    @SneakyThrows
    @Override
    public void onAssertSuccess(IAssert<?> assertCommand) {
        String filePath = "./target/cucumber-html-report/Report_Passed-Temp.txt";
        /*FileWriter fw1 = new FileWriter(filePath,true);
        PrintWriter pw1 = new PrintWriter(fw1);
*/
        PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(filePath,true)));

        String cmdMsg = String.format( "[%s]", assertCommand.getMessage());

  //      System.out.println(assertCommand.getMessage() + " <PASSED> ");
        pw.printf(cmdMsg + " <PASSED> "+"\n");
        pw.close();
        //fw1.close();
            }

    @SneakyThrows
    @Override
    public void onAssertFailure(IAssert<?> assertCommand, AssertionError ex)
    {
        String filePath1 = "./target/cucumber-html-report/Report_Failed-Temp.txt";
       // FileWriter fw2 = new FileWriter(filePath1,true);
      //  PrintWriter pw2 = new PrintWriter(fw2);

        PrintWriter pw2 = new PrintWriter(new BufferedWriter(new FileWriter(filePath1,true)));

        String suffix = String.format( "Expected [%s] but found [%s]", assertCommand.getExpected().toString(), assertCommand.getActual().toString());
//        System.out.println(assertCommand.getMessage() + " <FAILED>. " + suffix);
        String cmdMsg = String.format( "[%s]", assertCommand.getMessage());
        //String failedStr = " <FAILED>. ";
        String failedMsg = String.format("%s", " <FAILED>. ");

  //      pw2.printf(assertCommand.getMessage() + " <FAILED>. " + suffix+"\n");
        pw2.printf("%s %s %s",cmdMsg,failedMsg,suffix+"\n");

        pw2.close();
        //fw2.close();
    }
}
