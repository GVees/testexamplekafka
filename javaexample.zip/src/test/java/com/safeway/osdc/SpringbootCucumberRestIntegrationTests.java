package com.safeway.osdc;
import com.cucumber.listener.Reporter;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.File;

@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(classes = {ApplicationConfig.class})
public class SpringbootCucumberRestIntegrationTests {

	@Test
	public void contextLoads() {

  }

	public static void writeExtentReport() {
		Reporter.loadXMLConfig(new File("./report.xml"));
	}
}

