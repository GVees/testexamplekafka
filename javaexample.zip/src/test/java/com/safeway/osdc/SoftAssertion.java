package com.safeway.osdc;

import org.testng.asserts.SoftAssert;
import org.testng.Reporter;
public class SoftAssertion {

    Reporter Report = new Reporter();
    public SoftAssert softAssert = new SoftAssert();

    public SoftAssertion() {
    }

    public void assertAll(){
        softAssert.assertAll();
    }

    public void assertEquals(String actual, String expected, String failMessage, String passMessage) {
        if (actual.equals(expected)){
            softAssert.assertEquals( actual,  expected,  failMessage);
           // Report.testPass(passMessage);
        } else{
            softAssert.assertEquals( actual,  expected,  failMessage);
           // Report.testFail(failMessage);
        }
    }
}