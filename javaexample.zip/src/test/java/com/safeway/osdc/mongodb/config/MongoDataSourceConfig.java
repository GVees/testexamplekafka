package com.safeway.osdc.mongodb.config;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.MongoClientURI;
import org.springframework.boot.autoconfigure.mongo.MongoProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.mongodb.MongoDbFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.SimpleMongoDbFactory;

import javax.sql.DataSource;

@Configuration
public class MongoDataSourceConfig {

    @Bean
    @Primary
    @ConfigurationProperties(prefix = "datasource.mongodb.ocisconfig")
    public MongoProperties configProp(){
        return new MongoProperties();
    }

    @Bean
    @Primary
    public MongoDbFactory mongoConfigDbFactory() throws Exception{
        return new SimpleMongoDbFactory(new MongoClient(
                new MongoClientURI(configProp().getUri())),configProp().getDatabase());
    }

    @Bean ("configTemplate")
    @Primary
    public MongoTemplate mongoConfigTemplate() throws Exception{
        return new MongoTemplate(mongoConfigDbFactory());
    }

    @Bean
    @Primary
    public MongoClientOptions mongoOptions() {
        return MongoClientOptions
                .builder()
                .maxConnectionIdleTime(60000)
                .build();
    }


    @Bean
    @ConfigurationProperties(prefix = "datasource.mongodb.ocisruntime")
    public MongoProperties runtimeProp(){
        return new MongoProperties();
    }

    @Bean
    public MongoDbFactory mongoRunTimeDbFactory() throws Exception{
        return new SimpleMongoDbFactory(new MongoClient(new MongoClientURI(runtimeProp().getUri())),runtimeProp().getDatabase());
    }

    @Bean("runTimeTemplate")
    public MongoTemplate mongoRunTimeTemplate() throws Exception{
        return new MongoTemplate(mongoRunTimeDbFactory());
    }

 /*   @Bean
    public JDBCTemplate dataSource(): DataSource
    {
        return DataSourceBuilder.create()
                .driverClassName(databaseDriver)
                .url(sfUrl)
                .username(sfUser)
                .password(sfPassword())
                .build()
    }*/
}
