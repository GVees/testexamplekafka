package com.safeway.osdc.mongodb.osdcconfig.entities;

import lombok.Data;
import lombok.ToString;
import org.springframework.data.annotation.Id;

@Data
@ToString
public class Item {

    private String storeId;
    private String corporateItemCd;
    private String inventoryTypeCd;
    private String transactionTs;
    private String dwFirstEffectiveDt;
    private String dwLastEffectiveDt;
    private String upcId;
    private String inventoryTypeDsc;
    private String inventoryTypeShortDsc;
    private String ItemAvailability;
    private String sizeUOMCd;
    private String itemWeightCnt;
    private String weightUOMCd;
    private String palletQty;
    private String palletLayerInventoryUnitCnt;
    private String palletLayerCnt;
    private String statusCd;
    private String statusDes;
    private String statusEffectiveTs;
    private String statusReasonCd;
    private String statusReasonDsc;
    private String statusTimePeriodInclusiveInd;
    private String statusStartTs;
    private String startEndTs;
    private String statusTimeZoneCd;
    private String dwCreateTs;
    private String dwLastUpdateTs;
    private String dwSourceCreateNm;
    private String dwSourceUpdateNm;
    private String source;
    private String createdDtm;
    private String modifiedDtm;


   /* @Id
    private String id;
    private String bpnID;
    private String upcId;
    private String description;
    private String itemQty;
    private String source;
    private String storeId;
    private String itemAvailability;
    private String city;
    private String zipcode; */
}


