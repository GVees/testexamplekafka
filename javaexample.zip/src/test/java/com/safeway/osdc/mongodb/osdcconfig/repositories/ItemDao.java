package com.safeway.osdc.mongodb.osdcconfig.repositories;

import com.safeway.osdc.mongodb.osdcconfig.entities.Item;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;

@Component
public class ItemDao {
    @Autowired
    @Qualifier("configTemplate")
    MongoTemplate confTemp;

    public Item getItemByStoreIdAndUpcId(String storeId, String upcId) {
        Query query = new Query();
        query.addCriteria(Criteria.where("storeId").is(storeId).and("upcId").is(upcId));
        Item item = confTemp.findOne(query, Item.class, "RawFarInventoryConfig");
        return item;
    }
}
