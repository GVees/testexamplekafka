package com.safeway.osdc.helper;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.safeway.osdc.mongodb.osdcconfig.entities.Item;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;
import java.util.List;

@Slf4j
@Component
public class JsonReader {
    @Autowired
    ObjectMapper objectMapper;

    @Qualifier("webApplicationContext")
    @Autowired
    ResourceLoader resourceLoader;

    public List<Item> readItemFromJson(String filePath) throws IOException {
        Resource resource = resourceLoader.getResource("file:"+ filePath);
        return (List<Item>) readPayload(resource.getFile(), new TypeReference<List<Item>>() {
        });
    }

    private Object readPayload(File jsonFile, TypeReference typeReference) throws IOException {
        log.info("json file: {}", jsonFile);
        Object object = objectMapper.readValue(jsonFile, typeReference);
        log.info("Object read from json {}", object);
        return object;
    }
}
