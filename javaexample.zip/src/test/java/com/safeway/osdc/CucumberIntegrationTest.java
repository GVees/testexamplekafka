package com.safeway.osdc;
import com.cucumber.listener.Reporter;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import cucumber.api.testng.AbstractTestNGCucumberTests;
import org.junit.runner.RunWith;

import java.io.File;

@RunWith(Cucumber.class)
@CucumberOptions(
    features = "src/test/resources/features/",
    glue = {"com.safeway.osdc.stepdefinitions"},
    tags = {"not @ignore", "not @wip"},
    plugin = {
        "pretty",
        "html:target/cucumber-html-report",
        "json:target/cucumber-report.json",
  //      "com.cucumber.listener.ExtentCucumberFormatter:target/cucumber-reports/report.html",
        "rerun:target/cucumber-api-rerun.txt"
    },
        monochrome = true)

public class CucumberIntegrationTest extends AbstractTestNGCucumberTests{
    public static void writeExtentReport() {
        Reporter.loadXMLConfig(new File(""));
    }
}
