package com.safeway.osdc.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.safeway.osdc.mongodb.osdcconfig.entities.Item;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class KafkaProducerService {

    private String topicName = "OSDC_ITEM_INSERT_QA";

    @Autowired
    private KafkaTemplate<String, Object> kafkaTemplate;

    @Autowired
    ObjectMapper objectMapper;

    public boolean sendItemToKafka(Item item) {
        log.info(String.format("Message sent -> %s", item));
        try {
            objectMapper.writeValueAsString(item);
            this.kafkaTemplate.send(topicName, item);
            return true;
        } catch (Exception ee) {
            ee.printStackTrace();
        }
        return false;
    }
}
