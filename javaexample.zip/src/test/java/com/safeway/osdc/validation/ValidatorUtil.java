package com.safeway.osdc.validation;

import org.springframework.stereotype.Component;

import java.util.Objects;

@Component
public class ValidatorUtil {
    public boolean isEqual(String str1, String str2) {
        if (Objects.equals(str1, str2)) {
            return true;
        }
        return str1.equalsIgnoreCase(str2);
    }
}
