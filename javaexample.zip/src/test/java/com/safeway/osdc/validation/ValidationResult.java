package com.safeway.osdc.validation;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter @Setter
public class ValidationResult {
    private String status;
    private List<String> messages = new ArrayList<>();
    private List<String> errorMessages = new ArrayList<>();
}
