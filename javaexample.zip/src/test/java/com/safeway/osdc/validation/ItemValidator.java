package com.safeway.osdc.validation;

import com.safeway.osdc.mongodb.osdcconfig.entities.Item;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.function.Supplier;

@Component
public class ItemValidator {
    @Autowired
    private ValidatorUtil validatorUtil;

    public void isEqual(ValidationResult result, Item itemFromFile, Item itemFromMongo) {
        checkAndAdd(result, "Store Id", () -> itemFromFile.getStoreId(), () -> itemFromMongo.getStoreId());
        checkAndAdd(result, "Corporate Item Cd", () -> itemFromFile.getCorporateItemCd(), () -> itemFromMongo.getCorporateItemCd());
        checkAndAdd(result, "Inventory Type Cd", () -> itemFromFile.getInventoryTypeCd(), () -> itemFromMongo.getInventoryTypeCd());
        checkAndAdd(result, "Upc Id", () -> itemFromFile.getUpcId(), () -> itemFromMongo.getUpcId());
    }

    private void checkAndAdd(ValidationResult result, String fieldName, Supplier<String> fileDataSupplier, Supplier<String> mongoDataSupplier) {
        String fileData = fileDataSupplier.get();
        String mongoData = mongoDataSupplier.get();
        if (validatorUtil.isEqual(fileData, mongoData)) {
            result.getMessages().add(String.format("%s is matched. value from File: %s <=> value from Mongo: %s", fieldName, fileData, mongoData));
        } else {
            result.getErrorMessages().add(String.format("%s is NOT matched. value from File: %s <!=> value from Mongo: %s", fieldName, fileData, mongoData));
        }
    }
}
