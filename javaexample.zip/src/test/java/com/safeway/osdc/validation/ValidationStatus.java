package com.safeway.osdc.validation;

public class ValidationStatus {
    public static final String SUCCESS = "SUCCESS";
    public static final String FAILED = "FAILED";
}
