package com.safeway.osdc.stepdefinitions;

import com.safeway.osdc.SpringbootCucumberRestIntegrationTests;
import cucumber.api.java.After;
import cucumber.api.java.Before;

public class Hooks extends SpringbootCucumberRestIntegrationTests {

  //@Autowired FileUtils fileUtils;
 // @Autowired ScenarioContext scenarioContext;
  @Before
  public void setUp() throws Exception{
    //download the ShowHide file from hadoop server
  //  fileUtils.getHadoopShowHideFileToLocal();
  }

  @After
  public void tearDown(){
    //scenarioContext.clearAllFields();
  }

}
