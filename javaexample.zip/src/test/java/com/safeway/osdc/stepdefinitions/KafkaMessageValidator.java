package com.safeway.osdc.stepdefinitions;

import com.safeway.osdc.context.ItemValidatorContext;
import com.safeway.osdc.helper.JsonReader;
import com.safeway.osdc.mongodb.osdcconfig.entities.Item;
import com.safeway.osdc.mongodb.osdcconfig.repositories.ItemDao;
import com.safeway.osdc.service.KafkaProducerService;
import com.safeway.osdc.validation.ItemValidator;
import com.safeway.osdc.validation.ValidationResult;
import com.safeway.osdc.validation.ValidationStatus;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

import static com.safeway.osdc.validation.ValidationStatus.SUCCESS;

public class KafkaMessageValidator {
    static final Logger logger = LogManager.getLogger(KafkaMessageValidator.class);
    static final String path = "src/test/resources/log4j.properties";
    static final String itemFile = "C:/TestData/api/Item/itemfile.json";

    @Autowired
    private ItemValidatorContext itemValidatorContext;

    @Autowired
    private KafkaProducerService kafkaProducerService;

    @Autowired
    private JsonReader jsonReader;

    @Autowired
    private ItemValidator itemValidator;

    @Autowired
    private ItemDao itemDao;

    @Given("Processing data from File")
    public void processingFile() {
        try {
            List<Item> items = jsonReader.readItemFromJson(itemFile);
            itemValidatorContext.setItems(items);
            System.out.println("Items retrieved from files ->" + items);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @When("Data is getting Posted to Kafka")
    public void publishItemToKafka() {
        List<Item> items = itemValidatorContext.getItems();
        System.out.println("******* Number of Items from input -- >"+items.size());
        int noOfMessagePosted = 0;
        for (Item item : items) {  //forloop
            if (kafkaProducerService.sendItemToKafka(item)) {
                noOfMessagePosted += 1;
            }
        }//for loop
        itemValidatorContext.setNoOfMessagePublished(noOfMessagePosted);
        System.out.println("****** No of Items publish to kafka -- >" + noOfMessagePosted);
    }

    @Then("Ensure posted record inserted to Mongo properly")
    public void matchItemFromMongo() {
        List<Item> items = itemValidatorContext.getItems();
        int itemCount = items.size();
        int itemPublishedCount = itemValidatorContext.getNoOfMessagePublished();

        ValidationResult result = new ValidationResult();

        // 1. Number of records matched
        if (items.size() == itemPublishedCount) {
            result.getMessages().add(String.format("File count and number of message published is matched. Item from File: %s, No Of Message Posted: %s", itemCount, itemPublishedCount));
        } else {
            result.getErrorMessages().add(String.format("File count and number of message published is not matched. Item from File: %s, No Of Message Posted: %s", itemCount, itemPublishedCount));
        }

        for (Item item : items) {
            Item itemFromMongo = itemDao.getItemByStoreIdAndUpcId(item.getStoreId(), item.getUpcId());
            if (itemFromMongo == null) {
                // 2. Is Item persisted in Mongo
                result.getErrorMessages().add((String.format("Item from File: %s, is not found in Mongo", String.join("-", item.getStoreId(), item.getUpcId()))));
                continue;
            }
            // 3. Item from file match with item saved in Mongo
            itemValidator.isEqual(result, item, itemFromMongo);
        }

        result.setStatus(result.getErrorMessages().size() > 0 ? ValidationStatus.FAILED : SUCCESS );
        System.out.println("Is Item matched with Mongo: " + result.getStatus());

        if (SUCCESS.equals(result.getStatus())) {
            System.out.println("Match Cases");
            for (String message : result.getMessages()) {
                System.out.println(message);
            }
        }

        if (ValidationStatus.FAILED.equals(result.getStatus())) {
            System.out.println("Failed Cases");
            for (String errorMessage : result.getErrorMessages()) {
                System.out.println(errorMessage);
            }
        }
    }
}
