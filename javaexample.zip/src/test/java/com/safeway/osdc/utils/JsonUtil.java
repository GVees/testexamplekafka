package com.safeway.osdc.utils;

import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class JsonUtil {

  public static Gson gson = new GsonBuilder().create();

  public static String jsonFromMap(Map<String, Object> jsonMap){
    return gson.toJson(jsonMap);
  }

  public static String jsonFromObjectList(List<Object> list)
  {
	 return gson.toJson(list);
  }
  
  public static JsonArray jsonFromListMap(List<Map<String, Object>> jsonListMap){
    JsonArray jsonArray = new JsonArray();
    Iterator entries = jsonListMap.iterator();
    while(entries.hasNext()){
      jsonArray.add(gson.toJson(entries.next()));
    }
    return jsonArray;
  }

  public static <T> List<T> convertJsonToJavaObject(List<T> lst, Class<T> cls){
    String jsonStr;
    List<T> result = new ArrayList<T>();
    ObjectMapper map = new ObjectMapper();
    map.configure(MapperFeature.USE_STD_BEAN_NAMING,true);
    map.configure(MapperFeature.USE_STD_BEAN_NAMING.ACCEPT_CASE_INSENSITIVE_PROPERTIES,true);
    try {
      jsonStr = map.writeValueAsString(lst);
      result=  map.readValue(jsonStr,
            map.getTypeFactory().constructCollectionType(List.class, cls));
    }catch(Exception e){
      System.out.println(e);
    }
    return result;
  }

  public static <T> Object convertJsonToJavaObject(String jsonStr, Class<T> cls){
    Object result = new Object();
    ObjectMapper map = new ObjectMapper();
    map.configure(MapperFeature.USE_STD_BEAN_NAMING,true);
    map.configure(MapperFeature.USE_STD_BEAN_NAMING.ACCEPT_CASE_INSENSITIVE_PROPERTIES,true);
    try {
      result=  map.readValue(jsonStr, cls);
    }catch(Exception e){
      System.out.println(e);
    }
    return result;
  }


}
